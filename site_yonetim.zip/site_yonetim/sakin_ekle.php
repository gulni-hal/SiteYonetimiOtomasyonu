<?php
session_start();
include("baglanti.php");

if (!isset($_SESSION["yonetici"])) {
    header("Location: yonetici_giris.php");
    exit();
}

$mesaj = "";

// yonetici kullanici adini alarak onun sakin id sini buluyoruz
$yonetici_kullanici_adi = $_SESSION["yonetici"];
$stmt = $conn->prepare("SELECT sakinler.sakin_id 
                        FROM sakinler 
                        JOIN personel ON personel.sakin_id = sakinler.sakin_id 
                        WHERE sakinler.kullanici_adi = ?");
$stmt->bind_param("s", $yonetici_kullanici_adi);
$stmt->execute();
$stmt->bind_result($sakin_id);
$stmt->fetch();
$stmt->close();

// sakin id ile yoneticinin blok id sini aliyoruz
$stmt = $conn->prepare("SELECT blok_id FROM personel WHERE sakin_id = ?");
$stmt->bind_param("i", $sakin_id);
$stmt->execute();
$stmt->bind_result($blok_id);
$stmt->fetch();
$stmt->close();

// blok id ile o blok adindaki daireleri cekiyoruz
$daireler = [];
$stmt = $conn->prepare("SELECT daire_id, daire_numarasi FROM daireler WHERE blok_id = ?");
$stmt->bind_param("i", $blok_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $daireler[] = $row;
}
$stmt->close();

// girilen bilgilerdeki sakini ekliyoruz
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $ad_soyad = $_POST["ad_soyad"];
    $email = $_POST["email"];
    $numara = $_POST["numara"];
    $kullanici_adi = $_POST["kullanici_adi"];
    $sifre = $_POST["sifre"]; 
    $daire_id = $_POST["daire_id"];
    $kayit_tarihi = date("Y-m-d");

    $stmt = $conn->prepare("INSERT INTO sakinler (ad_soyad, email, numara, kayit_tarihi, kullanici_adi, sifre, daire_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssi", $ad_soyad, $email, $numara, $kayit_tarihi, $kullanici_adi, $sifre, $daire_id);

    if ($stmt->execute()) {
        $mesaj = "✅ Sakin başarıyla eklendi.";
    } else {
        $mesaj = "❌ Hata: " . $stmt->error;
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Sakin Ekle</title>
    <style>
        body {
            background-color: #e3f6f6;
            font-family: 'Segoe UI', sans-serif;
            text-align: center;
        }
        .form-container {
            margin-top: 50px;
            background-color: #fff;
            border: 4px solid #033c3c;
            border-radius: 25px;
            width: 500px;
            margin-left: auto;
            margin-right: auto;
            padding: 30px;
        }
        input, select {
            width: 90%;
            padding: 10px;
            margin: 10px auto;
            border: 1px solid #033c3c;
            border-radius: 10px;
            font-size: 16px;
        }
        input[type="submit"], .back-button {
            background-color: #033c3c;
            color: white;
            cursor: pointer;
            width: 50%;
            margin-top: 15px;
        }
        .back-button {
            display: inline-block;
            text-decoration: none;
            padding: 10px 20px;
            margin-top: 10px;
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <h2>Yeni Sakin Ekle</h2>
    <div class="form-container">

        <!-- Başarı veya hata mesajı -->
        <?php if (!empty($mesaj)): ?>
            <div style="color: <?= strpos($mesaj, 'Hata') !== false ? 'red' : 'green' ?>; font-weight: bold; margin-bottom: 10px;">
                <?= $mesaj ?>
            </div>
        <?php endif; ?>

        <form action="" method="POST">
            <input type="text" name="ad_soyad" placeholder="Ad Soyad" required>
            <input type="email" name="email" placeholder="Email">
            <input type="text" name="numara" placeholder="Telefon Numarası">
            <input type="text" name="kullanici_adi" placeholder="Kullanıcı Adı" required>
            <input type="password" name="sifre" placeholder="Şifre" required>
            <select name="daire_id" required>
                <option value="">Daire Seçin</option>
                <?php foreach ($daireler as $daire): ?>
                    <option value="<?= $daire['daire_id'] ?>">Daire <?= $daire['daire_numarasi'] ?></option>
                <?php endforeach; ?>
            </select>
            <input type="submit" value="Sakini Ekle">
        </form>

        <a class="back-button" href="sakinleri_listele.php">⟵ Geri Dön</a>
    </div>
</body>
</html>

