<?php
session_start();
include("baglanti.php");


if (!isset($_SESSION["yonetici"])) {
    header("Location: yonetici_giris.php");
    exit();
}

$yonetici_kullanici_adi = $_SESSION["yonetici"];

// yoneticinin sakin id si aliniyor
$stmt = $conn->prepare("SELECT sakin_id FROM sakinler WHERE kullanici_adi = ?");
$stmt->bind_param("s", $yonetici_kullanici_adi);
$stmt->execute();
$stmt->bind_result($sakin_id);
$stmt->fetch();
$stmt->close();

// sakin id si ile blok id si aliniyor
$stmt = $conn->prepare("SELECT blok_id FROM personel WHERE sakin_id = ?");
$stmt->bind_param("i", $sakin_id);
$stmt->execute();
$stmt->bind_result($yonetici_blok_id);
$stmt->fetch();
$stmt->close();

// blok id si ile blok adi aliniyor
$stmt = $conn->prepare("SELECT blok_adi FROM bloklar WHERE blok_id = ?");
$stmt->bind_param("i", $yonetici_blok_id);
$stmt->execute();
$stmt->bind_result($blok_adi);
$stmt->fetch();
$stmt->close();

// sakin id gecerli olup olmadigi kontrolu
if (!isset($_GET['sakin_id']) || !is_numeric($_GET['sakin_id'])) {
    echo "Geçersiz istek!";
    exit();
}

$sakin_id = intval($_GET['sakin_id']);

// silinecek sakin ilgili yoneticinin blogunda mi kontrolu
$kontrol_query = "
 SELECT s.sakin_id
FROM sakinler s
JOIN daireler d ON s.daire_id = d.daire_id
WHERE s.sakin_id = ? AND d.blok_id = ?

";
$stmt = $conn->prepare($kontrol_query);
$stmt->bind_param("ii", $sakin_id, $yonetici_blok_id);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    $stmt->close();
    ?>
    <!DOCTYPE html>
    <html lang="tr">
    <head>
        <meta charset="UTF-8">
        <title>Yetkisiz İşlem</title>
        <style>
            body {
                font-family: 'Segoe UI', sans-serif;
                background-color: #fff4f4;
                color: #b00020;
                text-align: center;
                padding-top: 100px;
            }
            .button {
                display: inline-block;
                margin-top: 30px;
                padding: 12px 24px;
                background-color: #b00020;
                color: white;
                text-decoration: none;
                border-radius: 10px;
                transition: background-color 0.3s ease;
            }
            .button:hover {
                background-color: #8a0018;
            }
        </style>
    </head>
    <body>
        <h2>⚠️ Bu sakini silmeye yetkiniz yok.</h2>
        <p>Sadece kendi bloğunuzdaki sakinleri silebilirsiniz.</p>
        <a href="sakinleri_listele.php" class="button">⟵ Geri Dön</a>
    </body>
    </html>
    <?php
    exit();
}
$stmt->close();

// 6. Silme işlemini yap
$stmt = $conn->prepare("DELETE FROM sakinler WHERE sakin_id = ?");
$stmt->bind_param("i", $sakin_id);

if ($stmt->execute()) {
    $stmt->close();
    header("Location: sakinleri_listele.php?durum=silindi");
    exit();
} else {
    $stmt->close();
    ?>
    <!DOCTYPE html>
    <html lang="tr">
    <head>
        <meta charset="UTF-8">
        <title>Silme Hatası</title>
        <style>
            body {
                font-family: 'Segoe UI', sans-serif;
                background-color: #fff4f4;
                color: #b00020;
                text-align: center;
                padding-top: 100px;
            }
            .button {
                display: inline-block;
                margin-top: 30px;
                padding: 12px 24px;
                background-color: #b00020;
                color: white;
                text-decoration: none;
                border-radius: 10px;
                transition: background-color 0.3s ease;
            }
            .button:hover {
                background-color: #8a0018;
            }
        </style>
    </head>
    <body>
        <h2>❌ Sakini silerken bir hata oluştu.</h2>
        <p>Lütfen daha sonra tekrar deneyiniz.</p>
        <a href="sakinleri_listele.php" class="button">⟵ Geri Dön</a>
    </body>
    </html>
    <?php
    exit();
}
?>
