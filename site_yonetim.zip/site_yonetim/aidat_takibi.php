<?php
include("baglanti.php");
session_start();

// Eğer yöneticinin girişi yapılmamışsa yönlendir.
if (!isset($_SESSION["yonetici"])) {
    header("Location: yonetici_giris.php");
    exit();
}

// kullanici adiyla sakin id aliyoruz sakin id si ile de blok id sini aliyoruz
$yonetici_kullanici_adi = $_SESSION["yonetici"];
$yonetici_sql = "
    SELECT p.blok_id 
    FROM personel p
    JOIN sakinler s ON p.sakin_id = s.sakin_id
    WHERE s.kullanici_adi = ? AND p.pozisyon = 'Yonetici'
";
$stmt = $conn->prepare($yonetici_sql);
$stmt->bind_param("s", $yonetici_kullanici_adi);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("Yönetici bulunamadı.");
}
$row = $result->fetch_assoc();
$blok_id = $row['blok_id'];

// blok id sinin karsilik geldigi blok adini aliyoruz
$blok_adi_sorgu = "SELECT blok_adi FROM bloklar WHERE blok_id = ?";
$stmt_blok = $conn->prepare($blok_adi_sorgu);
$stmt_blok->bind_param("i", $blok_id);
$stmt_blok->execute();
$blok_sonuc = $stmt_blok->get_result();
$blok_adi = $blok_sonuc->fetch_assoc()["blok_adi"];

// guncelleme isleminin yapildigi alan
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['daire_id'], $_POST['ay_yil'], $_POST['durum'])) {
    $daire_id = $_POST['daire_id'];
    $ay_yil = $_POST['ay_yil'];
    $durum = $_POST['durum'];

    
    $check_sql = "SELECT * FROM aidatlar WHERE daire_id=? AND ay_yil=?";
    $stmt = $conn->prepare($check_sql);
    $stmt->bind_param("is", $daire_id, $ay_yil);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // kayit varsa guncelliyor
        $update_sql = "UPDATE aidatlar SET durum=? WHERE daire_id=? AND ay_yil=?";
        $update = $conn->prepare($update_sql);
        $update->bind_param("sis", $durum, $daire_id, $ay_yil);
        $update->execute();
    } else {
        // kayit yoksa ekliyor
        $insert_sql = "INSERT INTO aidatlar (daire_id, ay_yil, durum) VALUES (?, ?, ?)";
        $insert = $conn->prepare($insert_sql);
        $insert->bind_param("iss", $daire_id, $ay_yil, $durum);
        $insert->execute();
    }
}

// ayin secildigi yer
$bugun = date("Y-m");
$secilen_ay = isset($_GET['ay_yil']) ? $_GET['ay_yil'] : $bugun;

// yoneticinin blok id ye gore yoneticinin blogundaki daireleri aliyor ve naire numarasina gore siraliyor (ekrandaki daire1, daire2, daire3 gorunumu)
$daireler_sql = "SELECT * FROM daireler WHERE blok_id = ? ORDER BY daire_numarasi ASC";
$stmt = $conn->prepare($daireler_sql);
$stmt->bind_param("i", $blok_id);
$stmt->execute();
$daireler_result = $stmt->get_result();
?>


<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Aidat Takibi</title>
    <style>
        body {
            background-color: #d9f4f4;
            font-family: 'Segoe UI', sans-serif;
            text-align: center;
        }
        h2 {
            margin-top: 30px;
            color: #033c3c;
        }
        table {
            margin: 30px auto;
            border-collapse: collapse;
            width: 90%;
            background-color: #fff;
        }
        th, td {
            padding: 12px;
            border: 1px solid #033c3c;
            text-align: center;
        }
        select, input[type="month"] {
            padding: 6px;
            border-radius: 8px;
            border: 1px solid #033c3c;
        }
        input[type="submit"] {
            background-color: #033c3c;
            color: white;
            padding: 8px 14px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }
        a {
            color: #033c3c;
            text-decoration: none;
            float: right;
            margin: 20px;
            font-size: 18px;
        }
    </style>
</head>
<body>

<h2><?= $blok_adi ?> Blok Aidat Takibi</h2>
<a href="yonetici_panel.php">⟵ Geri Dön</a>

<!-- Ay seçimi formu -->
<form method="get">
    <label for="ay_yil">Ay Seç:</label>
    <input type="month" id="ay_yil" name="ay_yil" value="<?= htmlspecialchars($secilen_ay) ?>" min="2025-01" max="2030-12">
    <input type="submit" value="Göster">
</form>


<!-- Aidat tablosu -->
<table>
    <tr>
        <th>Daire No</th>
        <th>Durum</th>
        <th>Güncelle</th>
    </tr>

    <?php while($daire = $daireler_result->fetch_assoc()): 
        $daire_id = $daire['daire_id'];

        // Mevcut durumu al
        $durum_sql = "SELECT durum FROM aidatlar WHERE daire_id=? AND ay_yil=?";
        $stmt_durum = $conn->prepare($durum_sql);
        $stmt_durum->bind_param("is", $daire_id, $secilen_ay);
        $stmt_durum->execute();
        $durum_result = $stmt_durum->get_result();
        $durum = ($durum_result->num_rows > 0) ? $durum_result->fetch_assoc()['durum'] : "Ödenmedi";
    ?>
    <tr>
        <form method="post">
            <td><?= $daire["daire_numarasi"] ?></td>
            <td>
                <select name="durum">
                    <option value="Ödenmedi" <?= $durum == "Ödenmedi" ? "selected" : "" ?>>Ödenmedi</option>
                    <option value="Ödendi" <?= $durum == "Ödendi" ? "selected" : "" ?>>Ödendi</option>
                </select>
            </td>
            <td>
                <input type="hidden" name="daire_id" value="<?= $daire_id ?>">
                <input type="hidden" name="ay_yil" value="<?= $secilen_ay ?>">
                <input type="submit" value="Kaydet">
            </td>
        </form>
    </tr>
    <?php endwhile; ?>
</table>

</body>
</html>

