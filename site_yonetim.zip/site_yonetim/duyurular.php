<?php
include("baglanti.php");

$sql = "
SELECT d.baslik, d.icerik, d.tarih, b.blok_adi 
FROM duyurular d
LEFT JOIN bloklar b ON d.hedef_blok_id = b.blok_id
ORDER BY d.tarih DESC
";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Duyurular</title>
    <style>
        body {
            background-color: #e3f6f6;
            font-family: 'Segoe UI', sans-serif;
            padding-top: 50px; 
        }
        .duyuru {
            background-color: white;
            border: 2px solid #033c3c;
            border-radius: 15px;
            margin: 20px auto;
            padding: 20px;
            width: 70%;
        }
        .duyuru h3 {
            color: #033c3c;
        }
        .duyuru small {
            color: #555;
        }
        .button {
            margin-top: 20px;
            display: inline-block;
            padding: 10px 30px;
            border: 1px solid #033c3c;
            border-radius: 30px;
            background-color: white;
            font-size: 16px;
            color: #033c3c;
            text-decoration: none;
        }
        .button:hover {
            background-color: #d3f1f1;
        }
        .top-right {
            position: fixed;
            right: 30px;
            top: 20px; 
            z-index: 100; 
        }
    </style>
</head>
<body>
    <a class="button top-right" href="index.php">⟵ Geri</a> 

    <h2 style="text-align:center;">📢 Duyurular</h2>

    <?php while ($row = $result->fetch_assoc()): ?>
        <div class="duyuru">
            <h3><?= htmlspecialchars($row['baslik']) ?></h3>
            <small>
                <?= htmlspecialchars($row['tarih']) ?> - 
                <?= $row['blok_adi'] ? htmlspecialchars($row['blok_adi']) . " Blok" : "Tüm Bloklar" ?>
            </small>
            <p><?= nl2br(htmlspecialchars($row['icerik'])) ?></p>
        </div>
    <?php endwhile; ?>
</body>
</html>

