<?php
session_start();
include("baglanti.php");

if (!isset($_SESSION["yonetici"])) {
    header("Location: yonetici_giris.php");
    exit();
}

$yonetici_kullanici_adi = $_SESSION["yonetici"];

// kullanici adi ile yoneticinin sakin id si bulunuyor
$stmt = $conn->prepare("SELECT sakin_id FROM sakinler WHERE kullanici_adi = ?");
$stmt->bind_param("s", $yonetici_kullanici_adi);
$stmt->execute();
$stmt->bind_result($sakin_id);
$stmt->fetch();
$stmt->close();

// sakin id si ile blok id si aliniyor
$stmt = $conn->prepare("SELECT blok_id FROM personel WHERE sakin_id = ?");
$stmt->bind_param("i", $sakin_id);
$stmt->execute();
$stmt->bind_result($yonetici_blok_id);
$stmt->fetch();
$stmt->close();

// blok id ile blok adi cekiliyor
$stmt = $conn->prepare("SELECT blok_adi FROM bloklar WHERE blok_id = ?");
$stmt->bind_param("i", $yonetici_blok_id);
$stmt->execute();
$stmt->bind_result($blok_adi);
$stmt->fetch();
$stmt->close();

// o blok adindaki daireler listeleniyor
$stmt = $conn->prepare("
    SELECT s.sakin_id, s.ad_soyad, s.email, s.numara, b.blok_adi, d.daire_numarasi
    FROM sakinler s
    JOIN daireler d ON s.daire_id = d.daire_id
    JOIN bloklar b ON d.blok_id = b.blok_id
    WHERE b.blok_adi = ?
");
$stmt->bind_param("s", $blok_adi);
$stmt->execute();
$result = $stmt->get_result();
?>


<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Sakinleri Listele</title>
    <style>
        body {
            background-color: #e3f6f6;
            font-family: 'Segoe UI', sans-serif;
            text-align: center;
            color: #033c3c;
        }
        h1 {
            margin-top: 30px;
        }
        
.button {
            margin: 10px 5px;
            padding: 10px 20px;
            border-radius: 25px;
            border: 1px solid #033c3c;
            background-color: white;
            color: #033c3c;
            text-decoration: none;
        }
.button:hover {
            background-color: #c1eaea;
}
        
        table {
            margin: 30px auto;
            border-collapse: collapse;
            width: 90%;
            background-color: white;
            border-radius: 12px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ccc;
        }
        th {
            background-color: #c1eaea;
        }
        tr:nth-child(even) {
            background-color: #f3fafa;
        }
    </style>
</head>
<body>

<div class="top-right" style="position:absolute; right:20px; top:20px;">
    <a class="button" href="yonetici_panel.php">⟵ Geri</a>
    <a class="button" href="cikis.php">Çıkış Yap</a>
</div>

<h1><?= htmlspecialchars($blok_adi) ?> Blok Sakinleri</h1>

<a href="sakin_ekle.php" class="button">➕ Sakin Ekle</a>

<table>
    <tr>
        <th>Ad Soyad</th>
        <th>Email</th>
        <th>Telefon</th>
        <th>Blok</th>
        <th>Daire No</th>
        <th>İşlemler</th>
    </tr>
    <?php if ($result->num_rows > 0): ?>
     <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['ad_soyad']) ?></td>
                <td><?= htmlspecialchars($row['email']) ?></td>
                <td><?= htmlspecialchars($row['numara']) ?></td>
                <td><?= htmlspecialchars($row['blok_adi']) ?></td>
                <td><?= htmlspecialchars($row['daire_numarasi']) ?></td>
                <td>
           
                   

    <a href="sakin_duzenle.php?id=<?= $row['sakin_id'] ?>" class="button">✏️ Düzenle</a>
    <a href="sakin_sil.php?sakin_id=<?= $row['sakin_id'] ?>" class="button" onclick="return confirm('Bu sakini silmek istediğinize emin misiniz?')">❌ Sil</a>


                   
            </tr>
        <?php endwhile; ?>


    <?php else: ?>
        <tr><td colspan="6">Bu blokta kayıtlı sakin bulunamadı.</td></tr>
    <?php endif; ?>
</table>

</body>
</html>


