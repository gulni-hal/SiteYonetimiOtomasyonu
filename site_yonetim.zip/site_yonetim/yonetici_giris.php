<?php
include("baglanti.php");
session_start();

$hata = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $kullanici_adi = $_POST["username"];
    $sifre = $_POST["password"];

    // JOIN KULLANNDIM BURDAAAA!!!
    $sql = "SELECT p.personel_id, s.kullanici_adi 
            FROM personel p
            JOIN sakinler s ON p.sakin_id = s.sakin_id
            WHERE s.kullanici_adi = ? AND s.sifre = ? AND p.pozisyon = 'Yonetici'";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $kullanici_adi, $sifre);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $_SESSION["yonetici"] = $kullanici_adi;
        header("Location: yonetici_panel.php");
        exit();
    } else {
        $hata = "Geçersiz kullanıcı adı veya şifre.";
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8" />
  <title>Yönetici Giriş</title>
  <style>
    body {
      background-color: #e3f6f6;
      font-family: 'Segoe UI', sans-serif;
      text-align: center;
    }
    .title-button {
      margin-top: 40px;
      display: inline-block;
      padding: 10px 30px;
      border: 1px solid #033c3c;
      border-radius: 30px;
      font-size: 20px;
      color: #033c3c;
    }
    .title-button::before {
      content: "👤 ";
    }
    .login-box {
      background-color: transparent;
      border: 6px solid #033c3c;
      border-radius: 50px;
      width: 400px;
      margin: 50px auto;
      padding: 50px 20px;
    }
    .login-box input {
      display: block;
      width: 80%;
      margin: 20px auto;
      padding: 15px;
      font-size: 18px;
      border-radius: 25px;
      border: 1px solid #033c3c;
      background-color: #e3f6f6;
    }
    .error-message {
      color: red;
      margin-top: 10px;
    }
     .button {
            margin-top: 20px;
            display: inline-block;
            padding: 10px 30px;
            border: 1px solid #033c3c;
            border-radius: 30px;
            background-color: white;
            font-size: 16px;
            color: #033c3c;
            text-decoration: none;
        }
        .button:hover {
            background-color: #d3f1f1;
        }
        .top-right {
            position: absolute;
            right: 30px;
            top: 20px;
        }
  </style>
</head>
<body>
     <a class="button" href="index.php">⟵ Geri</a>
  <div class="title-button">Yönetici Giriş Ekranı</div>
  <div class="login-box">
    <form action="" method="post">
      <label for="username">Kullanıcı Adı</label>
      <input type="text" name="username" id="username" required />
      <label for="password">Parola</label>
      <input type="password" name="password" id="password" required />
      <input type="submit" value="Giriş Yap" style="margin-top: 20px; padding: 10px 30px; font-size: 18px; border-radius: 20px; background-color: #033c3c; color: white; border: none; cursor: pointer;" />
    </form>
    <?php if ($hata != "") echo "<div class='error-message'>$hata</div>"; ?>
  </div>
</body>
</html>


