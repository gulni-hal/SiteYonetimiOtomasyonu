<?php
session_start();
include("baglanti.php");


if (!isset($_SESSION["yonetici"])) {
    header("Location: yonetici_giris.php");
    exit();
}

$yonetici_kullanici_adi = $_SESSION["yonetici"];


$stmt = $conn->prepare("SELECT sakin_id FROM sakinler WHERE kullanici_adi = ?");
$stmt->bind_param("s", $yonetici_kullanici_adi);
$stmt->execute();
$stmt->bind_result($sakin_id);
$stmt->fetch();
$stmt->close();

if (!$sakin_id) {
    echo "Yönetici bilgisi alınamadı.";
    exit();
}

// yoneticinin blok_id sini aliyoruz ki o blokta kalanlarin formlarini gorelim
$stmt = $conn->prepare("SELECT blok_id FROM personel WHERE sakin_id = ?");
$stmt->bind_param("i", $sakin_id);
$stmt->execute();
$stmt->bind_result($yonetici_blok_id);
$stmt->fetch();
$stmt->close();

if (!$yonetici_blok_id) {
    echo "Yöneticinin bağlı olduğu blok bulunamadı.";
    exit();
}

// ilgili yoneticinin kaldigi bloktaki dairelerin id sini aliyoruz
$daireler = [];
$stmt = $conn->prepare("SELECT daire_id FROM daireler WHERE blok_id = ?");
$stmt->bind_param("i", $yonetici_blok_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $daireler[] = $row['daire_id'];
}
$stmt->close();

// o dairelerde kalan sakinlerin id leriyle formlari aliyoruz ki ilgili yoneticinin ekraninda gozuksun
$basvurular = [];
if (!empty($daireler)) {
    $placeholders = implode(',', array_fill(0, count($daireler), '?'));
    $types = str_repeat('i', count($daireler));

    $query = "
        SELECT b.tur, b.icerik, b.tarih, s.ad_soyad, d.daire_numarasi 
        FROM basvurular b
        JOIN sakinler s ON b.sakin_id = s.sakin_id
        JOIN daireler d ON s.daire_id = d.daire_id
        WHERE s.daire_id IN ($placeholders)
        ORDER BY b.tarih DESC
    ";

    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$daireler);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $basvurular[] = $row;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Öneri / Talep / Şikayetler</title>
    <style>
        body {
            background-color: #e3f6f6;
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 90%;
            max-width: 1000px;
            margin: 40px auto;
            padding: 20px;
            background-color: white;
            border: 5px solid #033c3c;
            border-radius: 25px;
        }
        h2 {
            color: #033c3c;
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 30px;
        }
        th, td {
            padding: 15px;
            border: 1px solid #033c3c;
            text-align: left;
        }
        th {
            background-color: #d0f0f0;
            color: #033c3c;
        }
        .back-btn {
            display: inline-block;
            margin: 20px 0;
            padding: 10px 25px;
            background-color: #033c3c;
            color: white;
            border-radius: 20px;
            text-decoration: none;
        }
        .back-btn:hover {
            background-color: #025252;
        }
        .no-data {
            text-align: center;
            color: #777;
            font-size: 18px;
            margin-top: 30px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>📬 Öneri / Talep / Şikayetler</h2>

        <?php if (empty($basvurular)): ?>
            <p class="no-data">Henüz bir başvuru bulunmamaktadır.</p>
        <?php else: ?>
            <table>
                <tr>
                    <th>Gönderen</th>
                    <th>Daire No</th>
                    <th>Tür</th>
                    <th>İçerik</th>
                    <th>Tarih</th>
                </tr>
                <?php foreach ($basvurular as $basvuru): ?>
                    <tr>
                        <td><?= htmlspecialchars($basvuru['ad_soyad']) ?></td>
                        <td><?= htmlspecialchars($basvuru['daire_numarasi']) ?></td>
                        <td><?= htmlspecialchars($basvuru['tur']) ?></td>
                        <td><?= nl2br(htmlspecialchars($basvuru['icerik'])) ?></td>
                        <td><?= htmlspecialchars($basvuru['tarih']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>

        <a href="yonetici_panel.php" class="back-btn">← Geri Dön</a>
    </div>
</body>
</html>


