
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Veri Siteleri - Site Yönetim Sistemi</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <div class="logo">
            <div class="roof"></div>
            <h1>Veri<br>Siteleri</h1>
            <p class="subtitle">Site Yönetim Sistemi</p>
        </div>
        <div class="menu">
            <a href="duyurular.php" class="menu-item">📢 Duyurular <span>›</span></a>
            <a href="yonetici_giris.php" class="menu-item">👤 Yönetici Girişi <span>›</span></a>
            <a href="sakin_giris.php" class="menu-item">✍️ Öneri Talep ve Şikayetler <span>›</span></a>
        </div>
    </div>
</body>
</html>

