<?php
session_start();
include("baglanti.php");

if (!isset($_SESSION["yonetici"])) {
    header("Location: yonetici_giris.php");
    exit();
}

$yonetici_kullanici_adi = $_SESSION["yonetici"];

// yoneticinin blok id sini alarak hangi blok oldugunu buluyoruz
$stmt = $conn->prepare("SELECT s.sakin_id, p.blok_id FROM sakinler s JOIN personel p ON s.sakin_id = p.sakin_id WHERE s.kullanici_adi = ?");
$stmt->bind_param("s", $yonetici_kullanici_adi);
$stmt->execute();
$stmt->bind_result($sakin_id, $blok_id);
$stmt->fetch();
$stmt->close();

// blok id sini alarak blok adini aliyoruz
$stmt = $conn->prepare("SELECT blok_adi FROM bloklar WHERE blok_id = ?");
$stmt->bind_param("i", $blok_id);
$stmt->execute();
$stmt->bind_result($blok_adi);
$stmt->fetch();
$stmt->close();

// GET ile gelen sakin_id kontrol ediliyor
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "Geçersiz istek.";
    exit();
}
$sakin_id_duzenlenecek = (int)$_GET['id'];

// blok id ile o daireleri aliyoruz
$daireler = [];
$stmt = $conn->prepare("SELECT daire_id, daire_numarasi FROM daireler WHERE blok_id = ?");
$stmt->bind_param("i", $blok_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $daireler[] = $row;
}
$stmt->close();

// sakinin bilgileri aliyoruz
$stmt = $conn->prepare("SELECT ad_soyad, email, numara, kullanici_adi, daire_id FROM sakinler WHERE sakin_id = ?");
$stmt->bind_param("i", $sakin_id_duzenlenecek);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    echo "Sakin bulunamadı.";
    exit();
}
$sakin = $result->fetch_assoc();
$stmt->close();

// guncellenme isleminin yapildigi alan
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $ad_soyad = $_POST["ad_soyad"];
    $email = $_POST["email"];
    $numara = $_POST["numara"];
    $kullanici_adi = $_POST["kullanici_adi"];
    $daire_id = $_POST["daire_id"];

    $stmt = $conn->prepare("UPDATE sakinler SET ad_soyad = ?, email = ?, numara = ?, kullanici_adi = ?, daire_id = ? WHERE sakin_id = ?");
    $stmt->bind_param("ssssii", $ad_soyad, $email, $numara, $kullanici_adi, $daire_id, $sakin_id_duzenlenecek);

    if ($stmt->execute()) {
        echo "<script>alert('Sakin bilgileri güncellendi.'); window.location.href='sakinleri_listele.php';</script>";
        exit();
    } else {
        echo "Hata: " . $stmt->error;
    }

    $stmt->close();
}
?>


<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Sakin Düzenle</title>
    <style>
        body {
            background-color: #e3f6f6;
            font-family: 'Segoe UI', sans-serif;
            text-align: center;
        }
        .form-container {
            margin-top: 50px;
            background-color: #fff;
            border: 4px solid #033c3c;
            border-radius: 25px;
            width: 500px;
            margin-left: auto;
            margin-right: auto;
            padding: 30px;
        }
        input, select {
            width: 90%;
            padding: 10px;
            margin: 10px auto;
            border: 1px solid #033c3c;
            border-radius: 10px;
            font-size: 16px;
        }
        input[type="submit"], .back-button {
            background-color: #033c3c;
            color: white;
            cursor: pointer;
            width: 50%;
            margin-top: 15px;
        }
        .back-button {
            display: inline-block;
            text-decoration: none;
            padding: 10px 20px;
            margin-top: 10px;
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <h2>Sakin Düzenle</h2>
    <div class="form-container">
        <form action="" method="POST">
    <input type="text" name="ad_soyad" value="<?= htmlspecialchars($sakin['ad_soyad']) ?>" required>
    <input type="email" name="email" value="<?= htmlspecialchars($sakin['email']) ?>">
    <input type="text" name="numara" value="<?= htmlspecialchars($sakin['numara']) ?>">
    <input type="text" name="kullanici_adi" value="<?= htmlspecialchars($sakin['kullanici_adi']) ?>" required>
    <select name="daire_id" required>
        <?php foreach ($daireler as $daire): ?>
            <option value="<?= $daire['daire_id'] ?>" <?= ($daire['daire_id'] == $sakin['daire_id']) ? 'selected' : '' ?>>
                Daire <?= $daire['daire_numarasi'] ?>
            </option>
        <?php endforeach; ?>
    </select>
    <input type="submit" value="Güncelle">
</form>

        <a class="back-button" href="sakinleri_listele.php">⟵ Geri Dön</a>
    </div>
</body>
</html>
