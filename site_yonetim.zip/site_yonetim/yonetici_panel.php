<?php
session_start();
if (!isset($_SESSION["yonetici"])) {
    header("Location: yonetici_giris.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Yönetici Paneli</title>
  <style>
    body {
      background-color: #d9f1f1;
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      padding: 0;
      text-align: center;
    }

    .header {
      margin-top: 40px;
      font-size: 28px;
      color: #033c3c;
      font-weight: bold;
    }

    .logout {
      position: absolute;
      top: 20px;
      right: 30px;
      font-size: 18px;
      color: #033c3c;
      text-decoration: none;
    }

    .container {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      align-items: center;
      margin-top: 80px;
      gap: 50px;
    }

    .panel-button {
      width: 200px;
      height: 120px;
      background-color: white;
      border-radius: 15px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 20px;
      color: #033c3c;
      text-align: center;
      padding: 10px;
      box-shadow: 0px 2px 10px rgba(0,0,0,0.1);
      text-decoration: none;
      transition: 0.3s;
    }

    .panel-button:hover {
      transform: scale(1.05);
      background-color: #eefefe;
    }
  </style>
</head>
<body>

  <a href="cikis.php" class="logout">Çıkış Yap</a>
  <div class="header">Yönetici Ekranı</div>

  <div class="container">
    <a href="sakinleri_listele.php" class="panel-button">Sakinleri<br>Listele</a>
    <a href="aidat_takibi.php" class="panel-button">Aidat<br>Takibi</a>
    <a href="duyuru_ekle.php" class="panel-button">Duyuru<br>Ekleme</a>
    <a href="oneri_sikayet.php" class="panel-button">Öneri Talep ve<br>Şikayet Görüntüleme</a>
  </div>

</body>
</html>
