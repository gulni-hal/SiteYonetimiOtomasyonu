
<?php
session_start();
include("baglanti.php");

if (!isset($_SESSION["sakin"])) {
    header("Location: sakin_giris.php");
    exit();
}

$mesaj = "";
$sakin_kadi = $_SESSION["sakin"];

// formu dolduran kullanicinin id sini al 
$stmt = $conn->prepare("SELECT sakin_id, ad_soyad FROM sakinler WHERE kullanici_adi = ?");
$stmt->bind_param("s", $sakin_kadi);
$stmt->execute();
$stmt->bind_result($sakin_id, $ad_soyad);
$stmt->fetch();
$stmt->close();

// sakinin id si sistemde yoksa
if (!$sakin_id) {
    echo "Kullanıcı bulunamadı.";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tur = $_POST["tur"];
    $icerik = trim($_POST["icerik"]);

    if (!in_array($tur, ['Oneri', 'Talep', 'Sikayet'])) {
        $mesaj = "Geçersiz başvuru türü.";
    } elseif (strlen($icerik) < 10) {
        $mesaj = "Açıklama çok kısa. Lütfen daha detaylı yazınız.";
    } else {
        $stmt = $conn->prepare("INSERT INTO basvurular (sakin_id, tur, icerik) VALUES (?, ?, ?)");
        $stmt->bind_param("iss", $sakin_id, $tur, $icerik);
        if ($stmt->execute()) {
            $mesaj = "Başvurunuz başarıyla gönderildi.";
        } else {
            $mesaj = "Bir hata oluştu. Lütfen tekrar deneyin.";
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Başvuru Yap</title>
    <style>
        body {
            background-color: #e3f6f6;
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 90%;
            max-width: 600px;
            margin: 40px auto;
            padding: 30px;
            background-color: white;
            border: 5px solid #033c3c;
            border-radius: 25px;
        }
        h2 {
            color: #033c3c;
            text-align: center;
        }
        label {
            display: block;
            margin-top: 20px;
            font-weight: bold;
            color: #033c3c;
        }
        select, textarea {
            width: 100%;
            padding: 12px;
            margin-top: 10px;
            border-radius: 10px;
            border: 1px solid #033c3c;
            font-size: 16px;
        }
        button {
            margin-top: 25px;
            width: 100%;
            padding: 12px;
            background-color: #033c3c;
            color: white;
            border: none;
            font-size: 16px;
            border-radius: 20px;
            cursor: pointer;
        }
        button:hover {
            background-color: #025252;
        }
        .message {
            margin-top: 15px;
            color: green;
            text-align: center;
        }
        .back-link {
            display: block;
            margin-top: 20px;
            text-align: center;
            color: #033c3c;
            text-decoration: none;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Öneri / Talep / Şikayet Başvurusu</h2>
        <form method="POST" action="">
            <label for="tur">Başvuru Türü</label>
            <select name="tur" id="tur" required>
                <option value="">Seçiniz</option>
                <option value="Oneri">Öneri</option>
                <option value="Talep">Talep</option>
                <option value="Sikayet">Şikayet</option>
            </select>

            <label for="icerik">Açıklama</label>
            <textarea name="icerik" id="icerik" rows="5" required></textarea>

            <button type="submit">Gönder</button>
        </form>

        <?php if ($mesaj): ?>
            <div class="message"><?= htmlspecialchars($mesaj) ?></div>
        <?php endif; ?>

        <a href="sakin_giris.php" class="back-link">← Çıkış Yap</a>
    </div>
</body>
</html>
