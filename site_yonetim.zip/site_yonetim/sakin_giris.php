
<?php
include("baglanti.php");
session_start();

$hata = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $kullanici_adi = $_POST["username"];
    $sifre = $_POST["password"];

    $stmt = $conn->prepare("SELECT * FROM sakinler WHERE kullanici_adi = ? AND sifre = ?");
    $stmt->bind_param("ss", $kullanici_adi, $sifre);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $_SESSION["sakin"] = $kullanici_adi;
        header("Location: sakin_basvuru.php"); 
        exit();
    } else {
        $hata = "Geçersiz kullanıcı adı veya şifre.";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8" />
  <title>Sakin Giriş</title>
  <style>
    body {
      background-color: #e3f6f6;
      font-family: 'Segoe UI', sans-serif;
    }
    h1 {
      margin-left: 90px;
      padding-top: 30px;
      color: #033c3c;
    }
    .title-button {
      margin-top: 10px;
      display: inline-block;
      padding: 10px 30px;
      border: 1px solid #033c3c;
      border-radius: 30px;
      font-size: 20px;
      color: #033c3c;
      margin-left: 450px;
    }
    .title-button::before {
      content: "👤 ";
    }
    .login-box {
      background-color: transparent;
      border: 6px solid #033c3c;
      border-radius: 50px;
      width: 400px;
      margin: 50px auto;
      padding: 50px 20px;
      text-align: center;
    }
    .login-box input {
      display: block;
      width: 80%;
      margin: 15px auto;
      padding: 12px;
      font-size: 16px;
      border-radius: 25px;
      border: 1px solid #033c3c;
      background-color: #e3f6f6;
    }
    button {
      margin-top: 25px;
      padding: 12px 40px;
      font-size: 16px;
      background-color: #033c3c;
      color: white;
      border: none;
      border-radius: 30px;
      cursor: pointer;
    }
    button:hover {
      background-color: #025252;
    }
    .back-btn {
      display: block;
      margin-top: 20px;
      text-align: center;
      color: #033c3c;
      text-decoration: none;
    }
    .back-btn:hover {
      text-decoration: underline;
    }
    .error {
      color: red;
      margin-top: 10px;
    }
  </style>
</head>
<body>
  <h1>Öneri, Talep ve Şikayet</h1>
  <div class="title-button">Sakin Giriş Ekranı</div>
  <div class="login-box">
    <form method="post" action="">
      <label for="username">Kullanıcı Adı</label>
      <input type="text" name="username" id="username" required />

      <label for="password">Parola</label>
      <input type="password" name="password" id="password" required />

      <button type="submit">Giriş Yap</button>
    </form>

    <?php if ($hata): ?>
      <div class="error"><?= htmlspecialchars($hata) ?></div>
    <?php endif; ?>

    <a href="index.php" class="back-btn">← Geri Dön</a>
  </div>
</body>
</html>
