<?php
include("baglanti.php");
session_start();

if (!isset($_SESSION["yonetici"])) {
    header("Location: yonetici_giris.php");
    exit();
}

$kullanici_adi = $_SESSION["yonetici"];

$sqlYonetici = "
    SELECT p.*, s.kullanici_adi 
    FROM personel p 
    JOIN sakinler s ON p.sakin_id = s.sakin_id 
    WHERE s.kullanici_adi = ?
";
$stmt = $conn->prepare($sqlYonetici);
$stmt->bind_param("s", $kullanici_adi);
$stmt->execute();
$result = $stmt->get_result();
$yonetici = $result->fetch_assoc();
$yonetici_blok_id = $yonetici['blok_id'];

// Burda yoneticinin kendi blogu ya da tum bloklar seciliyor
$bloklar = [];
$sqlBloklar = "SELECT * FROM bloklar WHERE blok_id = ?";
$stmtBlok = $conn->prepare($sqlBloklar);
$stmtBlok->bind_param("i", $yonetici_blok_id);
$stmtBlok->execute();
$resBlok = $stmtBlok->get_result();
while ($row = $resBlok->fetch_assoc()) {
    $bloklar[] = $row;
}
$bloklar[] = ["blok_id" => "NULL", "blok_adi" => "Tüm Bloklar"]; 

$duyuru_basarili = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $baslik = $_POST["baslik"];
    $icerik = $_POST["icerik"];
    $tarih = date("Y-m-d H:i:s");;

    $hedef_blok_id_raw = $_POST["hedef_blok_id"];
    $hedef_blok_id = ($hedef_blok_id_raw === "NULL") ? null : (int)$hedef_blok_id_raw;

    if ($hedef_blok_id === null) {
        $sql = "INSERT INTO duyurular (baslik, icerik, tarih, hedef_blok_id) VALUES (?, ?, ?, NULL)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $baslik, $icerik, $tarih);
    } else {
        $sql = "INSERT INTO duyurular (baslik, icerik, tarih, hedef_blok_id) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssi", $baslik, $icerik, $tarih, $hedef_blok_id);
    }

    if ($stmt->execute()) {
        $duyuru_basarili = true;
    } else {
        $hata = "Hata: " . $stmt->error;
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Duyuru Ekle</title>
    <style>
        body {
            background-color: #e3f6f6;
            font-family: 'Segoe UI', sans-serif;
            text-align: center;
        }
        .form-container {
            margin-top: 50px;
            background-color: #fff;
            border: 4px solid #033c3c;
            border-radius: 25px;
            width: 500px;
            margin-left: auto;
            margin-right: auto;
            padding: 30px;
        }
        input, textarea, select {
            width: 90%;
            padding: 10px;
            margin: 10px auto;
            border: 1px solid #033c3c;
            border-radius: 10px;
            font-size: 16px;
        }
        input[type="submit"], .back-button {
            background-color: #033c3c;
            color: white;
            cursor: pointer;
            width: 50%;
            margin-top: 15px;
        }
        .back-button {
            display: inline-block;
            text-decoration: none;
            padding: 10px 20px;
            margin-top: 10px;
            border-radius: 10px;
        }
        .success {
            color: green;
            font-weight: bold;
            margin-top: 15px;
        }
    </style>
</head>
<body>
    <h2>Yeni Duyuru Ekle</h2>
    <div class="form-container">
        <?php if ($duyuru_basarili): ?>
            <div class="success">✅ Duyuru başarıyla eklendi!</div>
        <?php endif; ?>

        <?php if (!empty($hata)): ?>
            <div style="color:red;"><?= htmlspecialchars($hata) ?></div>
        <?php endif; ?>

        <form action="" method="post">
            <input type="text" name="baslik" placeholder="Duyuru Başlığı" required><br>
            <textarea name="icerik" rows="6" placeholder="Duyuru İçeriği" required></textarea><br>
            <select name="hedef_blok_id" required>
                <?php foreach ($bloklar as $blok): ?>
                    <option value="<?= $blok['blok_id'] ?>"><?= $blok['blok_adi'] ?></option>
                <?php endforeach; ?>
            </select><br>
            <input type="submit" value="Duyuruyu Yayınla"><br>
        </form>
        <a class="back-button" href="yonetici_panel.php">⟵ Geri Dön</a>
    </div>
</body>
</html>